/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monantuan67;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

/**
 *
 * @author WorkOnHust
 */
public class MonAn {
    private int Ma;
    private String Ten;
    private int Gia;
    private InputStream Anh;
    

    public int getMa() {
        return Ma;
    }

    public void setMa(int Ma) {
        this.Ma = Ma;
    }

    public MonAn(String Ten, int Gia) {
        this.Ten = Ten;
        this.Gia = Gia;
    }

    public String getTen() {
        return Ten;
    }

    public void setTen(String Ten) {
        this.Ten = Ten;
    }

    public MonAn(int Ma, String Ten, int Gia) {
        this.Ma = Ma;
        this.Ten = Ten;
        this.Gia = Gia;
    }
    
    public MonAn(String Ten, int Gia, String URLAnh) throws FileNotFoundException {
        this.Ten = Ten;
        this.Gia = Gia;
        this.Anh = new FileInputStream(URLAnh);
    }
    
    public MonAn(int Ma, String Ten, int Gia, InputStream Anh) throws FileNotFoundException {
        this.Ma = Ma;
        this.Ten = Ten;
        this.Gia = Gia;
        this.Anh = Anh;
    }

    public int getGia() {
        return Gia;
    }

    public void setGia(int Gia) {
        this.Gia = Gia;
    }
    
    public InputStream getAnh()
    {
        return Anh;
    }

}
