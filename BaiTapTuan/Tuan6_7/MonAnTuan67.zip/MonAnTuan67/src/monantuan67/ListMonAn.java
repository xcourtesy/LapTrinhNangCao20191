/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monantuan67;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author WorkOnHust
 */
public class ListMonAn {
    private final ArrayList<MonAn> monan = new ArrayList<>();
    private Connection conn = null;
    private PreparedStatement st = null;
    private ResultSet rs = null;
    private final String dbURL = "jdbc:mysql://localhost/qlmonan?useUnicode=yes&characterEncoding=UTF-8";
    private final String username = "root";
    private final String password = "root";
    private String sql;
    private FileInputStream inputStream = null;

    public ListMonAn() {
    }
    
    public void add(MonAn m)
    {
        monan.add(m);
        UpdateListToDataBase();
    }
    public void remove(int i)
    {
        monan.remove(i);
        UpdateListToDataBase();
    }

    public ArrayList<MonAn> getList() {
        LoadListFromDataBase();
        return monan;
    }
    
    public MonAn get(int i)
    {
        LoadListFromDataBase();
        return monan.get(i);
    }
    
    private boolean UpdateListToDataBase()
    {
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
             System.out.println("Kết nối thành công");
            }
            sql = "SET SQL_SAFE_UPDATES = 0;";
            st = conn.prepareStatement(sql);
            st.executeUpdate();
            
            sql = "DELETE FROM `MonAn` WHERE true;";
            st = conn.prepareStatement(sql);
            st.executeUpdate();
            
            sql = "INSERT INTO `MonAn`(`Ten`,`Gia`,`Anh`) VALUES(?,?,?);";
            // Tạo đối tượng thực thi câu lệnh Select
            for (MonAn i:monan)
            {
                st = conn.prepareStatement(sql);
                st.setString(1,i.getTen());
                st.setString(2, String.valueOf(i.getGia()));
                st.setBinaryStream(3,i.getAnh());
                // Thực thi
                st.executeUpdate();
            }
            st.close();
            conn.close();
            return true;
        } catch (Exception e) {
          e.printStackTrace();
          return false;
        }
    }
        private boolean LoadListFromDataBase()
    {
        try {
            monan.clear();
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
             System.out.println("Kết nối thành công");
            }
            sql = "SELECT * FROM `MonAn`;";
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.isBeforeFirst() == false) {
                System.out.println("Dữ liệu trống");;
            }
            else
            {
                // Trong khi chưa hết dữ liệu
                while (rs.next()) {
                    if(rs.getObject("Anh") == null)
                        monan.add(new MonAn(rs.getInt("Ma"),rs.getString("Ten"),rs.getInt("Gia")));
                    else
                    {
                        InputStream is = rs.getBlob("Anh").getBinaryStream();

                        monan.add(new MonAn(rs.getInt("Ma"),rs.getString("Ten"),rs.getInt("Gia"),is));
                    }
                }
            }

            st.close();
            conn.close();
            return true;
        } catch (Exception e) {
          e.printStackTrace();
          return false;
        }
    }
}
