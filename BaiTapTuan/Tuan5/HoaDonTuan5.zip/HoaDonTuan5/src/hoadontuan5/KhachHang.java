/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoadontuan5;

/**
 *
 * @author Luu
 */
public class KhachHang extends People{
    private int maKhachHang;

    public int getMaKhachHang() {
        return maKhachHang;
    }

    public void setMaKhachHang(int maKhachHang) {
        this.maKhachHang = maKhachHang;
    }

    public KhachHang(String name, String address) {
        super(name, address);
    }

    public KhachHang() {
    }
    
    

    public KhachHang(int maKhachHang, String name, String address) {
        super(name, address);
        this.maKhachHang = maKhachHang;
    }
    
    
}
