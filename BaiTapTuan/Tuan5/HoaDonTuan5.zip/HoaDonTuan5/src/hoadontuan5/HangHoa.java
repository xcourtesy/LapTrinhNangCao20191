/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoadontuan5;

/**
 *
 * @author Luu
 */
public class HangHoa {
    private int maHangHoa;
    private String name;
    private double donGia;

    public HangHoa() {
    }

    public HangHoa(int maHangHoa, String name, double donGia) {
        this.maHangHoa = maHangHoa;
        this.name = name;
        this.donGia = donGia;
    }

    public int getMaHangHoa() {
        return maHangHoa;
    }

    public void setMaHangHoa(int maHangHoa) {
        this.maHangHoa = maHangHoa;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }
}
