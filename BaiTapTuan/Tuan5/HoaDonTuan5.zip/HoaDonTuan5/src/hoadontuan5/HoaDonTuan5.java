/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hoadontuan5;

import java.util.ArrayList;

/**
 *
 * @author Luu
 */
public class HoaDonTuan5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        KhachHang _khachhang = new KhachHang(); 
        HoaDon _hoadon = new HoaDon();
        ArrayList<HangHoa> _hanghoa = new ArrayList<HangHoa>();
        ArrayList<ChiTietHoaDon> _cthoadon = new ArrayList<ChiTietHoaDon>();
        
        
        _hoadon.setMaHoaDon(100);
        _hanghoa.add(new HangHoa(1,"Bút Chì",3000));
        _hanghoa.add(new HangHoa(2,"Vở",5000));
        _hanghoa.add(new HangHoa(3,"Thước",2000));
        

        
        HoaDonView v = new HoaDonView(_khachhang,_hoadon, _hanghoa,_cthoadon);
        v.setVisible(true);
        
    }
    
}
