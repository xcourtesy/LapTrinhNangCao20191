/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paint;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import java.util.Stack;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author tinhpham
 */
public class Paint extends JFrame implements ActionListener, MouseListener,MouseMotionListener {
    private JPanel p;
    private int x0,y0,x1,y1;
    private JButton b,b2,b3,b4;
    private JTextField tb; 
    private JLabel lb;
    
    
    int step = 1000;
    int xlim = 10; // draw from -10 to 10 in horizontal axis
    int ylim = 500;// vertical axis is from 0 to 500
    double Xq = 2*(double)xlim/step; // X quantum
   // double Yq = 2*(5*Math.pow(xlim,2)+8)/step;

    double Xd; // X convert real to digital position
    double Yd;
    public Paint()
    {
        this.setSize(900, 700);
        this.setLayout(null);
        
        
        
        
        p = new JPanel();
        p.setBounds(30, 30, 500, 500);
        p.addMouseListener(this);
        p.addMouseMotionListener(this);
        p.setBackground(Color.white);
        this.add(p);
        b=new JButton("Draw y=sin(x)");
        b.setBounds(30, 540, 150, 30);
        b.addActionListener(this);
        this.add(b);
        
        b2 = new JButton("Draw y = 5*x^2+8");
        b2.setBounds(200,540,200,30); // x,y position , weight, height size
        b2.addActionListener(this);
        this.add(b2);
        
        b3 = new JButton("Draw tangent");
        b3.setBounds(420,540,200,30);
        b3.addActionListener(this);
        this.add(b3);
        
        b4 = new JButton("Draw Custom Function");
        b4.setBounds(30,580,200,30);
        b4.addActionListener(this);
        this.add(b4);
        
        tb = new JTextField();
        tb.setBounds(290, 580, 340, 30);
        this.add(tb);
        
        lb = new JLabel("y(x) = ");
        lb.setBounds(235,580,40,30);
        this.add(lb);
    }   

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        x0=e.getX();
        y0=e.getY();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        x1=e.getX();
        y1=e.getY();
        
        Graphics2D g=(Graphics2D)p.getGraphics();
        g.setColor(Color.red);
        g.setStroke(new BasicStroke(10.0f));
        g.drawLine(x1, y1, x0, y0);
        
        x0=x1;
        y0=y1;
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
    private void drawSin(JPanel p)
    {
        int Xm=p.getWidth(),Ym=p.getHeight(),X0=Xm/2,Y0=Ym/2;
        
        float Xs=(float)(Xm/(4*Math.PI));
        float Ys=(float)(Ym/(4));
        Graphics g=p.getGraphics();
        g.setColor(Color.red);
        g.drawLine(0, Y0, Xm, Y0);
        g.drawLine(X0, 0, X0, Ym);
        float x1,y1;
        int x11,y11,x12,y12;
        int x10=0,y10=0;
        for(int i=0;i<1000;i++)
        {
            x1=(float)(-2*Math.PI+(4*Math.PI/1000)*i);
            y1=(float)(Math.sin(x1));
            x11=(int)(x1*Xs);
            y11=(int)(y1*Ys);
            x12=X0+x11;
            y12=Y0-y11;
            if(i==0)
            {
                x10=x12;
                y10=y12;
            } else
            {
                g.drawLine(x10, y10, x12, y12);
                x10=x12;y10=y12;
            }
            
        }
        
    }
    
    private void drawFunc(JPanel p)
    {
        int Xm=p.getWidth(),Ym=p.getHeight(),X0=Xm/2,Y0=3*Ym/4;
        Graphics g=p.getGraphics();
        g.setColor(Color.red);
        g.drawLine(0, Y0, Xm, Y0);
        g.drawLine(X0, 0, X0, Ym);
        

        
        Xd = Xm/(2*xlim); // X convert real to digital position
        Yd = 3*(double)Ym/(4*ylim);
        
        double x10,y10;
        int x11,y11,x12=0,y12=0;
        
        for(int i = 0;i < step; i++)
        {
            x10 = Xq*i - xlim;
            y10 = 5*Math.pow(x10,2)+8;
            x11 = (int) (x10*Xd)+X0;
            y11 = (int) (-y10*Yd)+Y0;
            if (i != 0)
                  {
                      g.drawLine(x11, y11, x12, y12);
                  }

            x12 = x11;
            y12 = y11;
        }
    }
    private void drawTangent(JPanel p)
        {
            int Xm=p.getWidth(),Ym=p.getHeight(),X0=Xm/2,Y0=3*Ym/4;
            Graphics g=p.getGraphics();
            g.setColor(Color.BLUE);
            
            //Point A
            double x0 = 3, y0 = 4; // A(3,4)
            b3.setText("Draw tangent through ("+(int)x0+","+(int) y0+")");

            
            // Func y = 5*x^2 + 8
            // Differential of y:  y' = 10*x
            
            // Call M is point in y that tangent crosses. M(x1,y1)
            double x11,y11,x12,y12;
            // The tangent define   y = y'(x1)(x-x1) + y1
            //                      y = 10*x1*(x-x1)+5*x1^2+8
            // The tagent crosses A(3,4)
            //                      y0 = 10*x1*(x0-x1)+5*x1^2+8
            // We have equation -5x1^2+10*x0*x1+8-y0 = 0
            // We find roots of the above equation to find M(x1,y1)
            double delta = Math.pow(10*x0,2) - 4*(8-y0)*(-5);
            //System.out.println(delta);
            if(delta < 0)
                JOptionPane.showMessageDialog(null, "Can't find tangent");
            else
            {
                    x11 = (-10*x0 + Math.sqrt(delta))/(2*(-5));
                    x12 = (-10*x0 - Math.sqrt(delta))/(2*(-5));
                    y11 = 5*Math.pow(x11,2)+8;
                    y12 = 5*Math.pow(x12,2)+8;
                    //System.out.println(x11);
                    //System.out.println(x12);
                    
                    // draw tangent
                    

                    Xd = Xm/(2*xlim); // X convert real to digital position
                    Yd = 3*(double)Ym/(4*ylim);
                    
                    double x11r,y11r,x12r,y12r;
                    
                    int x110,y110,x111=0,y111=0;
                    int x120,y120,x121=0,y121=0;

                    for(int i = 0;i < step; i++)
                    {
                        x11r = Xq*i - xlim;
                        x12r = x11r;
                        y11r = 10*x11*(x11r-x11)+y11;
                        y12r = 10*x12*(x12r-x12)+y12;
                        x110 = (int) (x11r*Xd)+X0;
                        y110 = (int) (-y11r*Yd)+Y0;
                        x120 = (int) (x12r*Xd)+X0;
                        y120 = (int) (-y12r*Yd)+Y0;
                        if (i != 0)
                              {
                                  g.drawLine(x110, y110 , x111, y111);
                                  g.drawLine(x120, y120 , x121, y121);
                              }
                        x111 = x110;
                        y111 = y110;
                        x121 = x120;
                        y121 = y120;
                    }
            }
            
        }
    
    private void drawCustomFunc(JPanel p, String s)
    {
        if (checkRule(s))
        {
            int Xm=p.getWidth(),Ym=p.getHeight(),X0=Xm/2,Y0=3*Ym/4;
            Graphics g=p.getGraphics();
            g.setColor(Color.BLUE);
            g.drawLine(0, Y0, Xm, Y0);
            g.drawLine(X0, 0, X0, Ym);
            
            Xd = Xm/(2*xlim); // X convert real to digital position
            Yd = 3*(double)Ym/(4*ylim);

            double x10,y10;
            int x11,y11,x12=0,y12=0;

            for(int i = 0;i < step; i++)
            {
                x10 = Xq*i - xlim;
                y10 = evaluateString(s,x10);
                x11 = (int) (x10*Xd)+X0;
                y11 = (int) (-y10*Yd)+Y0;
                if (i != 0)
                      {
                          g.drawLine(x11, y11, x12, y12);
                      }
                x12 = x11;
                y12 = y11;
            }
        }
//        double a = evaluateString(s,4);
//        System.out.println(a);
    }
    
    private boolean checkRule(String s)
    {
        if (s.equals(""))
        {
            JOptionPane.showMessageDialog(null, "Empty Function ");
            return false;
        }
        else
        {
            String CharacterValid = "x0123456789+-*/()";
            String OperatorValid = "+-*/()";
            char[] str = s.toCharArray();
            for (int i = 0; i<str.length; i++)
            {
                if(CharacterValid.indexOf(str[i]) == -1)
                {
                    JOptionPane.showMessageDialog(null, "Character " +str[i]+ " is not valid");
                    return false;
                }
                
                if(i > 0 && i < (str.length-1))
                {
                    if(str[i] == '(' && OperatorValid.indexOf(str[i-1]) == -1)
                    {
                        JOptionPane.showMessageDialog(null, "Need operator * or / between number and (");
                        return false;
                    }
                    if(str[i] == ')' && OperatorValid.indexOf(str[i+1]) == -1)
                    {
                        JOptionPane.showMessageDialog(null, "Need operator * or / between ) and number");
                        return false;
                    }
                }
            }
            
            
        }
        return true;
    }
    
    private double evaluateString(String s, double x)
    {
        char[] expression = s.toCharArray();
        //System.out.print(expression);
        // Stack for operand
        Stack<Double> values = new Stack<Double>();
        // Stack for operator
        Stack<Character> opr = new Stack<Character>();
        
        for(int i = 0; i < expression.length; i++)
        {
            
            if (expression[i] == ' ')
                continue;
            if (expression[i] >= '0' && expression[i] <= '9')
            {
                // if operand has more than one digit
                 StringBuffer strbuffer = new StringBuffer();
                 while( i < expression.length && expression[i] >= '0' && expression[i] <= '9')
                 {
                     strbuffer.append(expression[i]);
                     if (i+1 < expression.length && expression[i+1] >= '0' && expression[i+1] <= '9')
                         i++;
                     else
                         break;
                     
                 }
                 values.push(Double.parseDouble(strbuffer.toString()));
                 
            }
            else if (expression[i] == 'x')
            {
                values.push(x);
            }
            else if (expression[i] == '(')
            {
                opr.push(expression[i]);
            }
            else if (expression[i] == ')')
            {
                while(opr.peek() != '(')
                    values.push(cal(opr.pop(),values.pop(),values.pop()));
                opr.pop();
            }
            else if(expression[i] == '+' || expression[i] == '-' ||expression[i] == '*' ||expression[i] == '/')
            {
                while(!opr.empty() && hasPriority(expression[i],opr.peek()))
                {
                    values.push(cal(opr.pop(),values.pop(),values.pop()));
                }
                //System.out.print(expression[i]);
                opr.push(expression[i]);
            }
//            System.out.println(values);
//            System.out.println(opr);
        }
        
        while(!opr.empty())
        {
            values.push(cal(opr.pop(),values.pop(),values.pop()));
        }
        return values.pop();
        
    }
    
    private double cal(char op, double b, double a)
    {
        switch(op)
                {
                    case '+': return a+b;
                    case '-': return a-b;
                    case '*': return a*b;
                    case '/': if(b==0)
                                    throw new UnsupportedOperationException("Cannot divide by zero"); 
                              else
                                    return a / b; 
                }
        return 0;
    }
    
    // Check if we need calculate operator in stack before add new operator
    // If old operator(opr2) need calculate early, return true 
    private boolean hasPriority(char opr1, char opr2)
    {
        if(opr2 == '(' || opr2 == ')')
            return false;
        if( (opr1 == '*' || opr1 == '/') && (opr2 == '+' || opr2 == '-'))
            return false;
        return true;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b)
        {
            drawSin(p);
        }
        if(e.getSource()==b2)
        {
            drawFunc(p);
        }
        if(e.getSource()==b3)
        {
            drawTangent(p);
        }
        if(e.getSource()==b4)
        {
            drawCustomFunc(p,tb.getText());
        }
    }
}
