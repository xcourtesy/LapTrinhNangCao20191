/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package luupaint;

/**
 *
 * @author Luu
 */
import java.awt.*;
import javax.swing.*;

public class LuuPaint {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
//        EventQueue.invokeLater(() ->
//        {
//            SimpleFrame frame = new SimpleFrame();
//            frame.setVisible(true);
//        });
        EventQueue.invokeLater(() ->
        {
            JFrame t = new NewJFrame();
            t.setVisible(true);
            t.setTitle("Paint - LuuNX 20152346");
            t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        });
    }
    
    
}

//class SimpleFrame extends JFrame
//{
//    Toolkit kit = Toolkit.getDefaultToolkit();
//    Dimension screenSize = kit.getScreenSize();
//    final JMenuBar menuBar = new JMenuBar();
//    JMenu HomeMenu = new JMenu("Home");
//    JMenu ViewMenu = new JMenu("View");
//    
//    public SimpleFrame()
//    {
//        menuBar.add(HomeMenu);
//        menuBar.add(ViewMenu);
//        setJMenuBar(menuBar);
//        setSize(screenSize.width/2, screenSize.height/2);
//        setLocationByPlatform(true);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        setTitle("Paint - LuuNX 20152346");
//    }
//
